package com.storereservation.storereservation.configuration.exception;

public class ExceptionHandler {
}
