package com.storereservation.storereservation.entity.reserveConstants;

public enum ArriveStatus {
    WAIT,
    ARRIVE,
    CANCEL;

    public static final ArriveStatus DEFAULT = WAIT;
}
