package com.storereservation.storereservation.dto.constants;

public enum Role {
    ROLE_MANAGER,
    ROLE_CUSTOMER;


}
