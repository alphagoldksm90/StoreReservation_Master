package com.storereservation.storereservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class StorereservationApplication {

    public static void main(String[] args) {
        SpringApplication.run(StorereservationApplication.class, args);
    }

}
